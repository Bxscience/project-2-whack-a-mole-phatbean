package com.example.ngaia.whacksomething;

import android.content.Intent;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.Random;

public class game3x4 extends AppCompatActivity {

    private ImageButton[] apples = new ImageButton[12];
    private TextView score;
    private int scoreN;
    private TextView time;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game3x4);
        apples[0] = (ImageButton) findViewById(R.id.apple7);
        apples[1] = (ImageButton) findViewById(R.id.apple8);
        apples[2] = (ImageButton) findViewById(R.id.apple9);
        apples[3] = (ImageButton) findViewById(R.id.apple10);
        apples[4] = (ImageButton) findViewById(R.id.apple11);
        apples[5] = (ImageButton) findViewById(R.id.apple12);
        apples[6] = (ImageButton) findViewById(R.id.apple13);
        apples[7] = (ImageButton) findViewById(R.id.apple14);
        apples[8] = (ImageButton) findViewById(R.id.apple15);
        apples[9] = (ImageButton) findViewById(R.id.apple16);
        apples[10] = (ImageButton) findViewById(R.id.apple17);
        apples[11] = (ImageButton) findViewById(R.id.apple18);
        for (ImageButton a: apples) a.setVisibility(View.INVISIBLE);
        score = (TextView) findViewById(R.id.score2);
        time = (TextView) findViewById(R.id.timer2);
        new CountDownTimer(60000, 1000) {
            public void onTick(long millisLeft) {
                time.setText(millisLeft / 1000 + "");
                if (millisLeft/1000 % 2 == 0) {
                    for (int i = 0; i < apples.length; i++) apples[i].setVisibility(View.INVISIBLE);
                    Random random = new Random();
                    int p = random.nextInt(12);
                    apples[p].setVisibility(View.VISIBLE);
                }
            }
            public void onFinish() {
                toFinish();
            }
        }.start();
    }
    public void toFinish() {
        Intent gratz = new Intent(this, congratulations.class);
        String message = score.getText().toString();
        gratz.putExtra(MainActivity.HIYA, message);
        startActivity(gratz);
    }
    public void onClick(View view) {
        for (ImageButton apple : apples) apple.setVisibility(View.INVISIBLE);
        scoreN++;
        score.setText("Score: " + scoreN);
    }
}
