package com.example.ngaia.whacksomething;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class congratulations extends AppCompatActivity {

    TextView score;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_congratulations);
        setReadOnly((TextView)findViewById(R.id.Congratulations), true);
        setReadOnly((TextView)findViewById(R.id.gameOver), true);
        setReadOnly((TextView)findViewById(R.id.displayScore), true);
        Intent intent = getIntent();
        String message = intent.getStringExtra(MainActivity.HIYA);
        score = (TextView) (findViewById(R.id.displayScore));
        score.setText(message);
    }

    public static void setReadOnly(final TextView view, final boolean readOnly) {
        view.setFocusable(!readOnly);
        view.setFocusableInTouchMode(!readOnly);
        view.setClickable(!readOnly);
        view.setLongClickable(!readOnly);
        view.setCursorVisible(!readOnly);
    }

    public void playAgain(View view) {
        startActivity(new Intent(this, MainActivity.class));
    }
}
