package com.example.ngaia.whacksomething;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.Random;

import android.os.CountDownTimer;

public class game2x3 extends AppCompatActivity {

    private ImageButton[] apples = new ImageButton[6];
    private TextView score;
    private int scoreN;
    private TextView time;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game2x3);
        apples[0] = (ImageButton) findViewById(R.id.apple1);
        apples[1] = (ImageButton) findViewById(R.id.apple2);
        apples[2] = (ImageButton) findViewById(R.id.apple3);
        apples[3] = (ImageButton) findViewById(R.id.apple4);
        apples[4] = (ImageButton) findViewById(R.id.apple5);
        apples[5] = (ImageButton) findViewById(R.id.apple6);
        score = (TextView) findViewById(R.id.score);
        time = (TextView) findViewById(R.id.timer);
        for (int i = 0; i < apples.length; i++) apples[i].setVisibility(View.INVISIBLE);

        new CountDownTimer(60000, 1000) {
            public void onTick(long millisLeft) {
                time.setText(millisLeft / 1000 + "");
                if (millisLeft/1000 % 2 == 0) {
                    for (int i = 0; i < apples.length; i++) apples[i].setVisibility(View.INVISIBLE);
                    Random random = new Random();
                    int p = random.nextInt(6);
                    apples[p].setVisibility(View.VISIBLE);
                }
            }
            public void onFinish() {
                toFinish();
            }
        }.start();
    }
    public void toFinish() {
        Intent gratz = new Intent(this, congratulations.class);
        String message = score.getText().toString();
        gratz.putExtra(MainActivity.HIYA, message);
        startActivity(gratz);
    }
    public void onClick(View view) {
        for (int i = 0; i < apples.length; i++) apples[i].setVisibility(View.INVISIBLE);
        scoreN++;
        score.setText("Score: " + scoreN);
    }
}
