package com.example.ngaia.whacksomething;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {
    public static final String HIYA = "com.example.whacksomething.MESSAGE";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void to2x3(View view) {
        Intent a = new Intent(this, game2x3.class);
        startActivity(a);
    }
    public void to3x4(View view) {
        Intent b = new Intent(this, game3x4.class);
        startActivity(b);
    }
    public void to4x5(View view) {
        Intent c = new Intent(this, game4x5.class);
        startActivity(c);
    }
}
