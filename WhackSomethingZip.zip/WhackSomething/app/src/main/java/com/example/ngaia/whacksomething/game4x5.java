package com.example.ngaia.whacksomething;

import android.content.Intent;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.Random;

public class game4x5 extends AppCompatActivity {

    private ImageButton[] apples = new ImageButton[20];
    private TextView score;
    private int scoreN;
    private TextView time;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game4x5);
        apples[0] = (ImageButton) findViewById(R.id.apple19);
        apples[1] = (ImageButton) findViewById(R.id.apple20);
        apples[2] = (ImageButton) findViewById(R.id.apple21);
        apples[3] = (ImageButton) findViewById(R.id.apple22);
        apples[4] = (ImageButton) findViewById(R.id.apple23);
        apples[5] = (ImageButton) findViewById(R.id.apple24);
        apples[6] = (ImageButton) findViewById(R.id.apple25);
        apples[7] = (ImageButton) findViewById(R.id.apple26);
        apples[8] = (ImageButton) findViewById(R.id.apple27);
        apples[9] = (ImageButton) findViewById(R.id.apple28);
        apples[10] = (ImageButton) findViewById(R.id.apple29);
        apples[11] = (ImageButton) findViewById(R.id.apple30);
        apples[12] = (ImageButton) findViewById(R.id.apple31);
        apples[13] = (ImageButton) findViewById(R.id.apple32);
        apples[14] = (ImageButton) findViewById(R.id.apple33);
        apples[15] = (ImageButton) findViewById(R.id.apple34);
        apples[16] = (ImageButton) findViewById(R.id.apple35);
        apples[17] = (ImageButton) findViewById(R.id.apple36);
        apples[18] = (ImageButton) findViewById(R.id.apple37);
        apples[19] = (ImageButton) findViewById(R.id.apple38);
        for (ImageButton a: apples) a.setVisibility(View.INVISIBLE);
        score = (TextView) findViewById(R.id.score3);
        time = (TextView) findViewById(R.id.timer3);
        new CountDownTimer(60000, 1000) {
            public void onTick(long millisLeft) {
                time.setText(millisLeft / 1000 + "");
                for (int i = 0; i < apples.length; i++) apples[i].setVisibility(View.INVISIBLE);
                Random random = new Random();
                int p = random.nextInt(20);
                apples[p].setVisibility(View.VISIBLE);
            }
            public void onFinish() {
                toFinish();
            }
        }.start();
    }
    public void toFinish() {
        Intent gratz = new Intent(this, congratulations.class);
        String message = score.getText().toString();
        gratz.putExtra(MainActivity.HIYA, message);
        startActivity(gratz);
    }
    public void onClick(View view) {
        for (ImageButton apple : apples) apple.setVisibility(View.INVISIBLE);
        scoreN++;
        score.setText("Score: " + scoreN);
    }

}
